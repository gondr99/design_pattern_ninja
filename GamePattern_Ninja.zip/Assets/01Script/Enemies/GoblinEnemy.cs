using Unity.Behavior;
using UnityEngine;

[BlackboardEnum]
public enum GoblinState
{
    PATROL, CHASE, ATTACK, HIT, DEAD
}

public class GoblinEnemy : BTEnemy
{
    
}
