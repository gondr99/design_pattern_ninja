using Unity.Behavior;

[BlackboardEnum]
public enum StoneBossState
{
    Static, Idle, Attack, MoveTo, Dead
}
