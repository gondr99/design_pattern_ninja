using UnityEngine;

public class StoneBoss : Enemy
{
    
}
