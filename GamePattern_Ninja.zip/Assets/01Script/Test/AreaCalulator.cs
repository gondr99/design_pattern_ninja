public class AreaCalulator
{
    public float GetArea(Shape shape)
    {
        return shape.CalculateArea();
    }
}
