public interface IAfterInitable
{
    public void AfterInitialize();
}
